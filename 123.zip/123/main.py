import asyncio
import psycopg2
from pywebio import start_server
from pywebio.input import *
from pywebio.output import *
from pywebio.session import run_async
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding

# Update the database connection details
db_params = {
    "database": "CTalk",
    "user": "postgres",
    "password": "dilnaz2003",
    "host": "localhost",
    "port": "5432",
}

con = psycopg2.connect(**db_params)
conn = psycopg2.connect(**db_params)

# Creating a cursor object using the cursor() method
cursor = conn.cursor()

# Dropping the MESS table if it already exists.
cursor.execute("DROP TABLE IF EXISTS MESS")

# Creating the MESS table as per requirement
sql = '''CREATE TABLE MESS(
    ID SERIAL PRIMARY KEY,
    NICKNAME VARCHAR(100),
    MESSAGE BYTEA,
    ENCRYPTED BOOLEAN
)'''

cursor.execute(sql)
print("Table created successfully........")
conn.commit()
# Closing the connection
conn.close()

online_users = set()
MAX_MESSAGES_COUNT = 100

# Generate a key pair for encryption and decryption
def generate_key_pair():
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    public_key = private_key.public_key()
    return private_key, public_key

# Encrypt a message using a public key
def encrypt_message(public_key, message):
    encrypted_message = public_key.encrypt(
        message.encode(),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return encrypted_message

# Decrypt a message using a private key
def decrypt_message(private_key, encrypted_message):
    decrypted_message = private_key.decrypt(
        encrypted_message,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return decrypted_message.decode()

private_key, public_key = generate_key_pair()

async def main():
    put_markdown("## 🧊 Welcome to the online chat!\nThis chat application fits within 100 lines of code!")

    msg_box = output()
    put_scrollable(msg_box, height=300, keep_bottom=True)

    # Request the user's nickname and validate it
    nickname = await input("Join the chat", required=True, placeholder="Your name", validate=lambda n: "Nickname already in use!" if n in online_users or n == '📢' else None)
    online_users.add(nickname)

    # Insert a message when a user joins the chat
    conn = psycopg2.connect(**db_params)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO MESS (NICKNAME, MESSAGE, ENCRYPTED) VALUES (%s, %s, %s)", (nickname, f'{nickname} joined the chat!', False))
    conn.commit()
    conn.close()

    msg_box.append(put_markdown(f'📢 `{nickname}` joined the chat'))

    refresh_task = run_async(refresh_msg(nickname, msg_box))

    while True:
        data = await input_group("💭 New encrypted message", [
            input(placeholder="Message text...", name="msg"),
            actions(name="cmd", buttons=["Send", {'label': "Exit the chat", 'type': 'cancel'}])
        ], validate=lambda m: ('msg', "Enter message text!") if m["cmd"] == "Send" and not m['msg'] else None)

        if data is None:
            break

        msg = data['msg']

        # Encrypt the message with the server's public key
        encrypted_msg = encrypt_message(public_key, msg)

        # Store the encrypted message in the database
        conn = psycopg2.connect(**db_params)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO MESS (NICKNAME, MESSAGE, ENCRYPTED) VALUES (%s, %s, %s)", (nickname, psycopg2.Binary(encrypted_msg), True))
        conn.commit()
        conn.close()

    refresh_task.close()

    online_users.remove(nickname)
    toast("You have left the chat!")

    # Insert a message when a user leaves the chat
    conn = psycopg2.connect(**db_params)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO MESS (NICKNAME, MESSAGE, ENCRYPTED) VALUES (%s, %s, %s)", (nickname, f'User `{nickname}` left the chat!', False))
    conn.commit()
    conn.close()

    msg_box.append(put_markdown(f'📢 User `{nickname}` left the chat!'))

async def refresh_msg(nickname, msg_box):
    conn = psycopg2.connect(**db_params)
    cursor = conn.cursor()
    last_id = 0

    while True:
        cursor.execute("SELECT * FROM MESS WHERE ID > %s", (last_id,))
        new_messages = cursor.fetchall()

        for message in new_messages:
            user, msg, encrypted = message[1], message[2], message[3]

            if encrypted:
                # Decrypt the message using the server's private key
                decrypted_msg = decrypt_message(private_key, bytes(msg))
                msg_box.append(put_markdown(f"`{user}`: {decrypted_msg}"))
            else:
                msg_box.append(put_markdown(f"`{user}`: {msg.tobytes().decode()}"))  # Convert msg to bytes and then decode

            last_id = message[0]

        await asyncio.sleep(1)

if __name__ == "__main__":
    start_server(main, debug=True, port=8080, cdn=False)
